#!/system/bin/sh
for p in /sys/devices/system/cpu/cpufreq/policy*; do echo schedutil > "$p/scaling_governor"; done
dumpsys deviceidle enable >/dev/null 2>&1
