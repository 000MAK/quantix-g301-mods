#!/system/bin/sh
# Quantix performance: CPU governor "performance" on both clusters, Doze off.
# MediaTek thermal/power protection (PPM THERMAL, PWR_THRO, DLPT) is left untouched.
until [ "$(getprop sys.boot_completed)" = 1 ]; do sleep 2; done
sleep 10
for p in /sys/devices/system/cpu/cpufreq/policy*; do
  echo performance > "$p/scaling_governor"
done
dumpsys deviceidle disable >/dev/null 2>&1
